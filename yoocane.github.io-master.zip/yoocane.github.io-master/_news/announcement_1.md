---
layout: post
date: 2015-10-22 15:59:00-0400
inline: true
---

A simple inline announcement.
